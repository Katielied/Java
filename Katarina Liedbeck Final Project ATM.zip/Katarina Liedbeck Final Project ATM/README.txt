Please type and Account ID to enter the program and do a transaction 
Any of the account id's below will enter the program.
Once your Id is correct, the program will allow you to choose between the transactions, withdraw, deposit, check balance, display my account and exit.
When choosing withdraw and deposit, the program will ask to enter the amount, and ask you to enter it in a correct format.
If entered in an incorrect format the program will ask you to re enter.
If the account is of type Checking, it will allow you to have an overdraft maximum amount which you will be able to withdraw from, however no more than the overdraft.
After each transaction, the program will ask you if you would like to do another transaction or not.
To exit the program, you must choose the exit transaction or reply "no" when asked if you would like to do another action.
The updated transaction made in the account will be written into the output file.

The accounts are:

name: Katie L
Id: 0
Balance: 50.00
Account type: Regular

Name: Mathew S
Id: 1
balance: 600.00
Account type: checking
Overdraft maximum: 50.00

name: Brandon S
Id: 2
Balance: 9800.00
Account type: Regular

Name: Chris S
Id: 3
balance: 450.00
Account type: checking
Overdraft maximum: 100.00

name: Hugo M
Id: 4
Balance: 5600.00
Account type: Regular

name: Nassia P
Id: 5
Balance: 1000.00
Account type: Regular

name: Barbie Q
Id: 6
Balance: 1000.00
Account type: Regular

name: Leo C
Id: 7
Balance: 4000.00
Account type:  checking
Overdraft maximum: 100.00


